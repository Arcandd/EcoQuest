package com.example.softwareengineering

import android.R
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.graphics.blue
import androidx.core.graphics.red
import com.example.softwareengineering.ui.theme.SoftwareEngineeringTheme


// width = 392.dp
// height = 759.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SoftwareEngineeringTheme {
                HomePage()
            }
        }
    }
}



@Preview(showBackground = true)
@Composable
fun AppPreview() {
    SoftwareEngineeringTheme {
        HomePage()
    }
}